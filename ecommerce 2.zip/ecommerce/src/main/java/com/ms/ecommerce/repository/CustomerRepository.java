package com.ms.ecommerce.repository;

import com.ms.ecommerce.dto.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
@Repository
public interface CustomerRepository
        extends JpaRepository<Customer,Integer> {

    public boolean existsByEmail(String email);
    public boolean existsByPhone(String phone);
}
