package com.ms.ecommerce.excpetion;

public class PhoneNumberAlreadyExistsException extends  Exception{
    @Override
    public String toString() {
        return this.getMessage();
    }

    public PhoneNumberAlreadyExistsException(String message) {
        super(message);
    }

}
