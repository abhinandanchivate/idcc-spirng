package com.ms.ecommerce.service;

import com.ms.ecommerce.dto.Customer;
import com.ms.ecommerce.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements  CustomerService {

    @Autowired
    private CustomerRepository customerRepository ;

    @Override
    public Customer addCustmer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public Optional<List<Customer>> getAllCustomers() {
       List<Customer> list =  customerRepository.findAll();
//       if(list.isEmpty())
//       {
//           return Optional.empty();
//       }
//       return Optional.of(list);
        return Optional.ofNullable(list);
    }

    @Override
    public Optional<Customer> getCustomerById(int id) {
        return customerRepository.findById(id);
    }

    @Override
    public String deleteCustomerById(int id) {
        return "";
    }

    @Override
    public Customer updateCustomerById(int id, Customer customer) {
        return null;
    }

    @Override
    public boolean existsByEmail(String email) {
        return customerRepository.existsByEmail(email);
    }

    @Override
    public boolean existsByPhone(String phone) {
        return customerRepository.existsByPhone(phone);
    }
}
