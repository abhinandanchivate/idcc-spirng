package com.ms.ecommerce.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int customerId;
    @NotBlank
    @Length(min = 5,max = 10,message = "min length is 5")
    private String firstName;
    @NotBlank
    private String lastName;
    @NotBlank
    @Length(min=15, max=50,message = "provide the valid email id")
    private String email;
    @NotBlank
    @Length(min=10,message = "provide valid phone number")
    @Size
    private String phone;

    private String address;

}
