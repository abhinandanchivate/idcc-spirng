package com.ms.ecommerce.controlleradvice;

import com.ms.ecommerce.error.response.ApiError;
import com.ms.ecommerce.excpetion.DataNotFoundException;
import com.ms.ecommerce.excpetion.PhoneNumberAlreadyExistsException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;

@ControllerAdvice
public class EcommerceAdvice {
@ExceptionHandler(PhoneNumberAlreadyExistsException.class)
    public ResponseEntity<?> handlePhoneNumberAlreadyExistsException(
            PhoneNumberAlreadyExistsException e) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ApiError
                        (HttpStatus.BAD_REQUEST,
                                "phone number already exists",
                                e));
    }
    @ExceptionHandler(DataNotFoundException.class)
    public ResponseEntity<?> handleDataNotFoundException(
            DataNotFoundException e) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new ApiError
                        (HttpStatus.NOT_FOUND,
                                "data not found",
                                e));
    }

//    @ExceptionHandler(value = MethodArgumentNotValidException.class)
//    public ResponseEntity<?>
//    postMethodValidationException(MethodArgumentNotValidException e){
//
//        HashMap<String,String> map = new HashMap<>();
//e.getFieldErrors().forEach(e3->{
//    String put = map.put(e3.getField(), e3.getDefaultMessage());
//});
//         return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                 .body(map);
//
//    }
}
