package com.ms.ecommerce.excpetion;

public class IdNotFoundException extends  Exception{
    @Override
    public String toString() {
        return this.getMessage();
    }

    public IdNotFoundException(String message) {
        super(message);
    }
}
