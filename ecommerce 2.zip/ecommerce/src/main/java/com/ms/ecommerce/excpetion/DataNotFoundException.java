package com.ms.ecommerce.excpetion;

public class DataNotFoundException extends Exception{
       @Override
        public String toString() {
            return this.getMessage();
        }

        public DataNotFoundException(String message) {
            super(message);
        }

    }

