package com.ms.ecommerce.service;

import com.ms.ecommerce.dto.Customer;

import java.util.List;
import java.util.Optional;

//@FunctionalInterface
public interface CustomerService {

    public abstract  Customer addCustmer(Customer customer) ;

    public Optional<List<Customer>> getAllCustomers();
    public Optional<Customer> getCustomerById(int id);
    public String deleteCustomerById(int id);
    public Customer updateCustomerById(int id, Customer customer);

    public boolean existsByEmail(String email);
    public boolean existsByPhone(String phone);

}
