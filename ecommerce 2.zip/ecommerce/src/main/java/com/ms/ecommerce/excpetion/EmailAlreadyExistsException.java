package com.ms.ecommerce.excpetion;

public class EmailAlreadyExistsException extends  Exception{
    @Override
    public String toString() {
        return this.getMessage();
    }

    public EmailAlreadyExistsException(String message) {
        super(message);
    }

}
