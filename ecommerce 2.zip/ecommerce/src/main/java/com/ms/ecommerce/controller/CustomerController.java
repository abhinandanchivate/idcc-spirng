package com.ms.ecommerce.controller;

import com.ms.ecommerce.dto.Customer;
import com.ms.ecommerce.error.response.ApiError;
import com.ms.ecommerce.excpetion.DataNotFoundException;
import com.ms.ecommerce.excpetion.EmailAlreadyExistsException;
import com.ms.ecommerce.excpetion.PhoneNumberAlreadyExistsException;
import com.ms.ecommerce.repository.CustomerRepository;
import com.ms.ecommerce.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("/{id}")
    public ResponseEntity<?> getCustomerId(@PathVariable("id")int id)
            throws DataNotFoundException {
        Optional optional =customerService.getCustomerById(id);

        if(optional.isEmpty())
        {
            // failure
            throw new DataNotFoundException("id not found");
        }
        return ResponseEntity.status(200).body(optional.get());
    }

    @PostMapping("/add")
    public ResponseEntity<?> addCustomer(
            @RequestBody @Valid  Customer customer
    ) throws PhoneNumberAlreadyExistsException {

        HashMap<String, String> map = new HashMap<>();
        if(customerService.existsByEmail(customer.getEmail())
                ){
            map.put("email","email already exists");

//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(new ApiError(HttpStatus.BAD_REQUEST,
//                    "email already exists",
//                    new EmailAlreadyExistsException("email already used")));
        }
        if(customerService.existsByPhone(customer.getPhone())){

            map.put("phone","phone already exists");
        }

        if(!map.isEmpty()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
        }
        Customer customer2 = customerService.addCustmer(customer);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(customer2);
    }

    // /api/customers/all should retrieve all customer details
    // /api/customers/1 : should retrieve the specific id record.

    @GetMapping("/all")
    public ResponseEntity<?> getAllCustomers() throws DataNotFoundException {

       Optional optional = customerService.getAllCustomers();

       List<Customer> list = (List<Customer>) optional.get();

        if(!list.isEmpty()){
            // data is present
            System.err.println("hello from if");
            return ResponseEntity.status(HttpStatus.OK).body(optional.get());
        }
        else {
            // no data
            // NoDataFoundException.
            throw new DataNotFoundException("No record found");
        }
//      return ResponseEntity.status(200).body(customerService.getAllCustomers()
//              .orElseThrow(()->
//                      new DataNotFoundException("no record found")))  ;



    }

}
